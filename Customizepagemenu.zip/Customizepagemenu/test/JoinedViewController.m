//
//  JoinedViewController.m
//  test
//
//  Created by Kanisht on 9/19/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import "JoinedViewController.h"

@interface JoinedViewController ()

@end

@implementation JoinedViewController
@synthesize tableView;
@synthesize productList;
@synthesize imageOfProduct;
@synthesize imageList;

- (void)viewDidLoad {
    [super viewDidLoad];

    
    /*********************************** Table containing onclick data of tabs *********************/
    productList = [[NSMutableArray alloc]initWithObjects:@"Group 1",@"Group 2",@"Group 3",@"Group 4",@"Group 5",@"Group 6",@"Group 7",@"Group 8", nil];
    imageList = [[NSMutableArray alloc]initWithObjects:@"g1",@"g2",@"g1",@"g2",@"g1",@"g2",@"g1",@"g2", nil];
    
        /*********************************** Adding Views **********************************************/
        UIView *superview = self.view;
        self.tableView = [self makeTableView];
        [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [superview addSubview:self.tableView];
    


   
        UIEdgeInsets padding = UIEdgeInsetsMake(20, 20, 0, 0);
        [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(superview.mas_top).with.offset(padding.top);
            make.left.equalTo(superview.mas_left).with.offset(padding.left);
            make.bottom.equalTo(superview.mas_bottom).with.offset(-padding.bottom);
            make.right.equalTo(superview.mas_right).with.offset(-padding.right);
        }];
    


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*********************************** Configure Table **********************************************/
-(UITableView *)makeTableView
{
    UITableView *tableView = [[UITableView alloc]init];
   
    int rowHeight = 60;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        rowHeight = 100;
    }
    tableView.rowHeight = rowHeight;
    tableView.sectionFooterHeight = 22;
    tableView.sectionHeaderHeight = 22;
    tableView.scrollEnabled = YES;
    tableView.showsVerticalScrollIndicator = YES;
    tableView.userInteractionEnabled = YES;
    tableView.bounces = YES;
    tableView.delegate = self;
    tableView.dataSource = self;
    return tableView;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return productList.count;
}


/*********************************** Configure Cell *****************************************/
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *identifier = @"Cell";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:identifier ];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] ;
    
    UIView *textField = [[UIView alloc]init];
    UILabel *labelName = [[UILabel alloc]init];
    UILabel *labelDescription = [[UILabel alloc]init];
    UILabel *labelNumber = [[UILabel alloc]init];
    [textField addSubview:labelName];
    [textField addSubview:labelDescription];
    [textField addSubview:labelNumber];
    [cell.contentView addSubview:textField ];
    
    imageOfProduct = [[UIImageView alloc]init];
    imageOfProduct.image = [UIImage imageNamed:imageList[indexPath.row]];
    UIImageView *favourite =  [[UIImageView alloc]init];
    favourite.image = [UIImage imageNamed:@"g1"];
    [cell.contentView addSubview:favourite];
    [cell.contentView addSubview:imageOfProduct];


    int imageHeight = 50;
    int paddingLeft = 75;
    int labelNameHeight = 17;
    int favouriteImageHeight = 20;
    labelName.font = [UIFont boldSystemFontOfSize:15];
    [labelDescription setFont:[UIFont fontWithName:@"Helvetica Neue" size:13]];
    [labelNumber setFont:[UIFont fontWithName:@"Helvetica Neue" size:13]];
    labelName.text = [productList objectAtIndex:indexPath.row];
    labelDescription.text = @"Description";
    labelNumber.text = @"Number";
    labelDescription.textColor = [UIColor darkGrayColor];
    labelNumber.textColor = [UIColor darkGrayColor];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        imageHeight = 90;
        paddingLeft = 120;
        labelNameHeight = 25;
        favouriteImageHeight = 30;
        labelName.font = [UIFont boldSystemFontOfSize:21];
        [labelDescription setFont:[UIFont fontWithName:@"Helvetica Neue" size:17]];
        [labelNumber setFont:[UIFont fontWithName:@"Helvetica Neue" size:17]];
    }
    
    
    UIEdgeInsets padding = UIEdgeInsetsMake(0, paddingLeft, 0, 0);
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.contentView.mas_top).with.offset(padding.top); //with is an optional semantic filler
        make.left.equalTo(cell.contentView.mas_left).with.offset(padding.left);
        make.bottom.equalTo(cell.contentView.mas_bottom).with.offset(-padding.bottom);
        make.right.equalTo(cell.contentView.mas_right).with.offset(-padding.right);
    }];
    
    UIEdgeInsets paddingOfFavourite = UIEdgeInsetsMake(4, 0, 0, 20);
    [favourite mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.contentView.mas_top).with.offset(paddingOfFavourite.top); //with is an optional semantic filler
        make.right.equalTo(cell.contentView.mas_right).with.offset(-paddingOfFavourite.right);
        make.height.mas_equalTo(favouriteImageHeight);
        make.width.mas_equalTo(favouriteImageHeight);
        favourite.layer.cornerRadius = favouriteImageHeight / 2;
        favourite.clipsToBounds = YES;
    }];
    
    
    UIEdgeInsets paddinglabelName = UIEdgeInsetsMake(4, 0, 0, 0);
    [labelName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(textField.mas_top).with.offset(paddinglabelName.top); //with is an optional semantic filler
        make.left.equalTo(textField.mas_left).with.offset(paddinglabelName.left);
        make.height.mas_equalTo(labelNameHeight);
        make.right.equalTo(favourite.mas_left).with.offset(-paddinglabelName.right);
    }];
    
    UIEdgeInsets paddinglabelName2 = UIEdgeInsetsMake(0, 0, 0, 0);
    [labelDescription mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(labelName.mas_bottom).with.offset(paddinglabelName2.top); //with is an optional semantic filler
        make.left.equalTo(textField.mas_left).with.offset(paddinglabelName2.left);
        make.height.mas_equalTo(labelNameHeight);
        make.right.equalTo(textField.mas_right).with.offset(-paddinglabelName2.right);
    }];
    
    UIEdgeInsets paddinglabelName3 = UIEdgeInsetsMake(0, 0, 0, 0);
    [labelNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(labelDescription.mas_bottom).with.offset(paddinglabelName3.top); //with is an optional semantic filler
        make.left.equalTo(textField.mas_left).with.offset(paddinglabelName3.left);
        make.height.mas_equalTo(labelNameHeight);
        make.right.equalTo(textField.mas_right).with.offset(-paddinglabelName3.right);
    }];

    
    UIEdgeInsets padding1 = UIEdgeInsetsMake(4, 2, 2, 2);
    [imageOfProduct mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.contentView.mas_top).with.offset(padding1.top); //with is an optional semantic filler
        make.left.equalTo(cell.contentView.mas_left).with.offset(padding1.left);
        make.height.mas_equalTo(imageHeight);
        make.width.mas_equalTo(imageHeight);
        imageOfProduct.layer.cornerRadius = 10 / 2;
        imageOfProduct.clipsToBounds = YES;
    }];
    
    
    
    
    return cell;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
