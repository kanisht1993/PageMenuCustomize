//
//  ViewController.h
//  test
//
//  Created by Kanisht on 9/16/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"
#import "CAPSPageMenu.h"
#import "JoinedViewController.h"
#import "ProfileCompletedViewController.h"
#import "InvitationViewController.h"



@interface ViewController : UIViewController<UIScrollViewDelegate>
@property (nonatomic) CAPSPageMenu *pageMenu;
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) UITextField *textField;
@property (strong, nonatomic) NSMutableArray *productList;
@property (strong, nonatomic) NSMutableArray *imageList;
@property (strong, nonatomic) UIImageView *imageOfProduct;
@end

