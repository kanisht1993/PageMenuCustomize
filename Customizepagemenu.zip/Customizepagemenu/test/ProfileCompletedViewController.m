//
//  JoinedViewController.m
//  test
//
//  Created by Kanisht on 9/19/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import "ProfileCompletedViewController.h"

@interface ProfileCompletedViewController ()

@end

@implementation ProfileCompletedViewController
@synthesize tableView;
@synthesize productList;
@synthesize imageOfProduct;
@synthesize imageList;
@synthesize textField;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    /*********************************** Table containing onclick data of tabs *********************/
    productList = [[NSMutableArray alloc]initWithObjects:@"Nick Name",@"First Name",@"Last Name",@"Email",@"Phone",@"Date of Birth",@"Gender",@"USA", nil];
    imageList = [[NSMutableArray alloc]initWithObjects:@"User",@"User",@"User",@"Email",@"Phone",@"calendar",@"Address",@"Address", nil];
    /*********************************** Adding Views **********************************************/
    UIView *superview = self.view;
    self.tableView = [self makeTableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    [superview addSubview:self.tableView];
    
    UIImageView *upperImage = [[UIImageView alloc]init];
    [superview addSubview:upperImage];
    UIImage *bannerPic = [UIImage imageNamed:@"profile"];
    upperImage.image = bannerPic;
    
    
    UIEdgeInsets padding = UIEdgeInsetsMake(20, 20, 0, 0);
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(upperImage.mas_bottom).with.offset(padding.top);
        make.left.equalTo(superview.mas_left).with.offset(padding.left);
        make.bottom.equalTo(superview.mas_bottom).with.offset(-padding.bottom);
        make.right.equalTo(superview.mas_right).with.offset(-padding.right);
    }];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*********************************** Configure Table **********************************************/
-(UITableView *)makeTableView
{
    UITableView *tableView = [[UITableView alloc]init];
    
    int rowHeight = 45;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        rowHeight = 70;
    }
    tableView.rowHeight = rowHeight;
    tableView.sectionFooterHeight = 22;
    tableView.sectionHeaderHeight = 22;
    tableView.scrollEnabled = YES;
    tableView.showsVerticalScrollIndicator = YES;
    tableView.userInteractionEnabled = YES;
    tableView.bounces = YES;
    tableView.delegate = self;
    tableView.dataSource = self;
    return tableView;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return productList.count;
}


/*********************************** Configure Cell *****************************************/
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *identifier = @"Cell";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:identifier ];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    
    textField = [[UITextField alloc]init];
    textField.placeholder = productList[indexPath.row];
    [cell.contentView addSubview:textField ];
    
    imageOfProduct = [[UIImageView alloc]initWithFrame:CGRectMake(0, 12, 20, 20)];
    [cell.contentView addSubview:imageOfProduct];
    imageOfProduct.image = [UIImage imageNamed:imageList[indexPath.row]];

    
    
    int imageHeight = 20;
    int imageWidth = 25;
    int paddingTop = 10;
    int paddingLeft = 60;
    int labelNameHeight = 20;
    int secondLabelNameHeight = 30;

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        imageHeight = 35;
        imageWidth = 40;
        paddingTop = 20;
        paddingLeft = 80;
        labelNameHeight = 40;
        secondLabelNameHeight = 50;

    }

    
    
    
    UIEdgeInsets padding = UIEdgeInsetsMake(0, paddingLeft, 0, 0);
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.contentView.mas_top).with.offset(padding.top); //with is an optional semantic filler
        make.left.equalTo(cell.contentView.mas_left).with.offset(padding.left);
        make.bottom.equalTo(cell.contentView.mas_bottom).with.offset(-padding.bottom);
        make.right.equalTo(cell.contentView.mas_right).with.offset(-padding.right);
    }];
    
    
    UIEdgeInsets padding1 = UIEdgeInsetsMake(paddingTop, 2, 2, 2);
    [imageOfProduct mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cell.contentView.mas_top).with.offset(padding1.top); //with is an optional semantic filler
        make.left.equalTo(cell.contentView.mas_left).with.offset(padding1.left);
        make.height.mas_equalTo(imageHeight);
        make.width.mas_equalTo(imageWidth);

    }];
    
    
    return cell;
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
