//
//  AppDelegate.h
//  test
//
//  Created by Kanisht on 9/16/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

