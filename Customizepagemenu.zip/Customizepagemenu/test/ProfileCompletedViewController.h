//
//  JoinedViewController.h
//  test
//
//  Created by Kanisht on 9/19/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"

@interface ProfileCompletedViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) UITextField *textField;
@property (strong, nonatomic) NSMutableArray *productList;
@property (strong, nonatomic) NSMutableArray *imageList;
@property (strong, nonatomic) UIImageView *imageOfProduct;
@end
