//
//  ViewController.m
//  test
//
//  Created by Kanisht on 9/16/16.
//  Copyright © 2016 Kanisht. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController
@synthesize tableView;
@synthesize textField;
@synthesize productList;
@synthesize imageOfProduct;
@synthesize imageList;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    /************************************************* all menu customization done here  start 5- 6 reveal ********************/
    NSMutableArray *pageMenuProgressLabel = [[NSMutableArray alloc]initWithObjects:@"30",@"50%",@"5", nil];  //pagemenu progress label
     NSMutableArray *pageMenuGroups = [[NSMutableArray alloc]initWithObjects:@"groups",@"profile",@"groups", nil];        // pagemenu groups name
     NSMutableArray *pageMenuImages = [[NSMutableArray alloc]initWithObjects:@"g1",@"g2",@"m1", nil];         // pagemenu icon images
    
    
    /************************************************* all menu customization done here  end ********************/
    
    
    /*********************************** Creating and Adding Views **********************************************/
    
    int iPhoneScroller = -20;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        iPhoneScroller = 0;
    }
    UIScrollView *scrollview = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollview.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height + (.488 * self.view.frame.size.height) - (.149 * self.view.frame.size.height) + iPhoneScroller);
    [self.view addSubview:scrollview];
    
    
    UIView *superview = self.view;
    UIImageView *upperImage = [[UIImageView alloc]init];
    [superview addSubview:upperImage];
    UIImage *bannerPic = [UIImage imageNamed:@"profile"];
    upperImage.image = bannerPic;
    
    
    
    UIImageView *profileImageView = [[UIImageView alloc]init];
    [superview addSubview:profileImageView];
    UIImage *profilePic = [UIImage imageNamed:@"profilePic"];
    profileImageView.image = profilePic;

    
    JoinedViewController *controller1 = [[JoinedViewController alloc]init];
    controller1.title = @"Joined";
    ProfileCompletedViewController *controller2 = [[ProfileCompletedViewController alloc]init];
    controller2.title = @"Nick name";
    InvitationViewController *controller3 = [[InvitationViewController alloc]init];
    controller3.title = @"Invitation";
    int CAPSFont   = 13;
    int CAPSHeight = 100;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
         CAPSFont  = 20;
         CAPSHeight= 150;
    }
    
    
    
    
    NSArray *controllerArray = @[controller1, controller2, controller3];
        NSDictionary *parameters = @{
                                     CAPSPageMenuOptionScrollMenuBackgroundColor: [UIColor whiteColor], //scrolling tap color.
                                     CAPSPageMenuOptionViewBackgroundColor: [UIColor whiteColor], //default color of nib.
                                     CAPSPageMenuOptionSelectionIndicatorColor: [UIColor orangeColor],
                                     CAPSPageMenuOptionBottomMenuHairlineColor: [UIColor greenColor], //end line of scrolling tap color.
                                     CAPSPageMenuOptionMenuItemFont: [UIFont boldSystemFontOfSize:CAPSFont], // font of scrolling text.
                                     CAPSPageMenuOptionMenuHeight: @(CAPSHeight),
                                     CAPSPageMenuOptionMenuItemWidth: @((self.view.frame.size.width - 100) / 3),
                                     CAPSPageMenuOptionCenterMenuItems: @(YES),
                                     CAPSPageMenuOptionUnselectedMenuItemLabelColor:[UIColor darkGrayColor],
                                     CAPSPageMenuOptionSelectedMenuItemLabelColor:[UIColor lightGrayColor]
         
                                     
    /************************************************* all menu customization done here  start 6 - 6 reveal ********************/};
    _pageMenu = [[CAPSPageMenu alloc] initWithViewControllers:controllerArray pageMenuLabelProgress:pageMenuProgressLabel pageMenuLabelgroups:pageMenuGroups pageMenuImage:pageMenuImages frame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) options:parameters];
 [superview addSubview:_pageMenu.view];
    
    /************************************************* all menu customization done here  end ********************/


    
    /*********************************** Adding Masonry Constraints to Views **************************/
  
    
        UIEdgeInsets upperImageConstrints = UIEdgeInsetsMake(0, 0, 0, 0);
        [upperImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(scrollview.mas_top).with.offset(upperImageConstrints.top);
            make.left.equalTo(superview.mas_left).with.offset(upperImageConstrints.left);
            make.right.equalTo(superview.mas_right).with.offset(-upperImageConstrints.right);
            make.height.mas_equalTo(.488 * superview.frame.size.height);
          
        }];
        
        UIEdgeInsets profileImageViewConstraints = UIEdgeInsetsMake(-(.149 * superview.frame.size.height) / 2, 0, 0, 0);
        [profileImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(upperImage.mas_bottom).with.offset(profileImageViewConstraints.top);
            make.centerX.equalTo(upperImage);
            make.height.mas_equalTo(.149 * superview.frame.size.height);
            make.width.mas_equalTo(.149 * superview.frame.size.height);
            profileImageView.layer.cornerRadius = (.149 * superview.frame.size.height) / 2;
            profileImageView.clipsToBounds = YES;
        }];
    
    UIEdgeInsets pageMenu = UIEdgeInsetsMake(10, 0, 0, 0);
    [_pageMenu.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(profileImageView.mas_bottom).with.offset(pageMenu.top);
        make.left.equalTo(superview.mas_left).with.offset(pageMenu.left);
        make.bottom.equalTo(superview.mas_bottom).with.offset(-pageMenu.bottom);
        make.right.equalTo(superview.mas_right).with.offset(-pageMenu.right);
    }];

 
    /************************************* add subviews to scroller *********************************/
    
    [scrollview addSubview:upperImage];
    [scrollview addSubview:profileImageView];
    [scrollview addSubview:_pageMenu.view];
    
   
    
//    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
//        NSLog(@"i pad");
//    }
//    else{
//        NSLog(@"i phone");
//    }
    
   

}








@end






